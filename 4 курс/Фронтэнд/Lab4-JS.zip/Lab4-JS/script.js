window.addEventListener('load', () => {
    const startBtn = document.getElementById("start-btn");
    const startNewBtn = document.getElementById("start-new-btn");
    const progressBar = document.getElementById("progress");

    startNewBtn.style.visibility = "hidden";
    
    startBtn.addEventListener("click", () => {
     progressBar.style.display = "block";
     progressBar.animate([
      { width: "0%" },
      { width: "100%" }
     ], {
      duration: 5000,
      fill: "forwards",
      easing: "linear"
     }).onfinish = () => {
      progressBar.style.display = "none";
      alert("Файл загружен с помощью CSS animate!");
      startBtn.style.visibility = "hidden";
      startNewBtn.style.visibility = "visible";
     };
    });

    let step = 0;
    const allStep = 100;

    let intervalId;

    function translate(){
        step += 5;
        const currScale = step / allStep;
        progressBar.style.transform = "scaleX(" + currScale + ")"
        if (step > allStep){
            clearInterval(intervalId);
            alert("Файл загружен с помощью JS - скрипта");
            startNewBtn.style.visibility = "hidden";
            progressBar.style.display = "none";
        }
    }

    startNewBtn.addEventListener("click", () => {
        progressBar.style.display = "block";
        intervalId = setInterval(translate, 200);
    });
});