window.addEventListener("load", function() {
    const startBtn = document.getElementById("start-btn");
    const player = document.getElementById("player");

    const enemy1 = document.getElementById("enemy1");
    const enemy2 = document.getElementById("enemy2");
    const enemy3 = document.getElementById("enemy3");
    const enemy4 = document.getElementById("enemy4");
    const enemy5 = document.getElementById("enemy5");

    const playerSpeed = 15;

    let score = 0;

    enemy1.style.left = 0 + "px";
    enemy2.style.left = 120 + "px";
    enemy3.style.left = 240 + "px";
    enemy4.style.left = 360 + "px";
    enemy5.style.left = 488 + "px";

    const gameBoard = document.getElementById("game-board");

    const gameBoardRect = gameBoard.getBoundingClientRect();
    const gameBoardTop = gameBoardRect.top;
    const gameBoardBottom = gameBoardRect.bottom;
    const gameBoardLeft = gameBoardRect.left;
    const gameBoardRight = gameBoardRect.right;
  
    function movePlayer() {
      player.style.left = playerXPosition + "px";
      player.style.top = playerYPosition + "px";
    }
  
    function moveEnemy() {
      enemy1.style.top = enemyYPosition + "px";
      enemy2.style.top = enemyYPosition + "px";
      enemy3.style.top = enemyYPosition + "px";
      enemy4.style.top = enemyYPosition + "px";
      enemy5.style.top = enemyYPosition + "px";
    }
  
    function checkCollision() {
      const playerRect = player.getBoundingClientRect();
      
      const enemy1Rect = enemy1.getBoundingClientRect();
      const enemy2Rect = enemy2.getBoundingClientRect();
      const enemy3Rect = enemy3.getBoundingClientRect();
      const enemy4Rect = enemy4.getBoundingClientRect();
      const enemy5Rect = enemy5.getBoundingClientRect();

      const enemiesRect = [enemy1Rect, enemy2Rect, enemy3Rect, enemy4Rect, enemy5Rect];

      let i = 0;

      while(i < 5){
        if (
          playerRect.left >= enemiesRect[i].left &&
          playerRect.left < enemiesRect[i].right &&
          playerRect.top <= enemiesRect[i].bottom) {
            alert(`Game over! Your score: ${score}`);
            resetGame();
            break;
        }
        i++;
      }
    }
  
    function resetGame() {
      playerXPosition = gameBoardLeft - 30 - Math.random(5) * 100;
      playerYPosition = gameBoardBottom - 175;
      enemyYPosition = 0;
      enemySpeed = 1;
      enemyInterval = 10;

      score = 0;

      enemy1.style.left = 0 + "px";
      enemy2.style.left = 120 + "px";
      enemy3.style.left = 240 + "px";
      enemy4.style.left = 360 + "px";
      enemy5.style.left = 488 + "px";
      
      movePlayer();
      moveEnemy();
    }
  
    startBtn.addEventListener("click", () => {
      startBtn.style.visibility = false;

      playerXPosition = gameBoardLeft - 30 - Math.random(5) * 100;
      playerYPosition = gameBoardBottom - 175;

      score = 0;

      enemyYPosition = 0;
      enemySpeed = 1;
      enemyInterval = 10;
      movePlayer();
      moveEnemy();
  
      document.addEventListener("keydown", (event) => {
        if (event.key === "ArrowRight") {
          if (playerXPosition + playerSpeed <= 495){
            playerXPosition += playerSpeed;
            movePlayer();
          }
        } else if (event.key === "ArrowLeft") {
          if (playerXPosition - playerSpeed >= -1){
            playerXPosition -= playerSpeed;
            movePlayer();
          }
        }
      });
  
      setInterval(() => {
        if (enemyYPosition + enemySpeed <= 400){
          enemyYPosition += enemySpeed;
        }
        else {
          score ++;
          enemySpeed += 0.5;
          enemyYPosition = 0;

          const step = 20;
          const sign = (Math.random() >= 0.5) ? 1 : -1;
          totalStep = step * sign;
          
          enemy1.style.left = 0 + "px";
          enemy2.style.left = 120 - totalStep + "px";
          enemy3.style.left = 240 + totalStep + "px";
          enemy4.style.left = 360 - totalStep + "px";
          enemy5.style.left = 488 + "px";
        }
        moveEnemy();
        checkCollision();
      }, enemyInterval);
    });
  });