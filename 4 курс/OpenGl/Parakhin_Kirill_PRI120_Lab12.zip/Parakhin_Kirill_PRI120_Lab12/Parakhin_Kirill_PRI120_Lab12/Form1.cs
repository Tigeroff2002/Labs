﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tao.FreeGlut;
using Tao.OpenGl;

namespace Parakhin_Kirill_PRI120_Lab12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            AnT.InitializeContexts();
        }

        private struct TranslationCoord
        {
            public float X;
            public float Y;
            public float Z;

            public TranslationCoord(float x, float y, float z)
            {
                X = x;
                Y = y;
                Z = z;
            }
        }

        TranslationCoord[] figureCoords = new TranslationCoord[6];

        // вспомогательные переменные - в них будут хранится обработанные значения,
        // полученные при перетаскивании ползунков пользователем
        double a = 0, b = 0, c = -5, d = 0, zoom = 1; // выбранные оси
        int os_x = 1, os_y = 0, os_z = 0;

        Random rnd_next = new Random();

        // режим специальной визуализации
        bool SpecialMode = false;

        private void Form1_Load(object sender, EventArgs e)
        {
            // инициализация бибилиотеки glut
            Glut.glutInit();
            // инициализация режима экрана
            Glut.glutInitDisplayMode(Glut.GLUT_RGB | Glut.GLUT_DOUBLE);

            // установка цвета очистки экрана (RGBA)
            Gl.glClearColor(255, 255, 255, 1);

            // установка порта вывода
            Gl.glViewport(0, 0, AnT.Width, AnT.Height);

            // активация проекционной матрицы
            Gl.glMatrixMode(Gl.GL_PROJECTION);
            // очистка матрицы
            Gl.glLoadIdentity();

            // установка перспективы
            Glu.gluPerspective(45, (float)AnT.Width / (float)AnT.Height, 0.1, 200);

            Gl.glMatrixMode(Gl.GL_MODELVIEW);
            Gl.glLoadIdentity();

            // начальная настройка параметров openGL (тест глубины, освещение и первый источник света)
            Gl.glEnable(Gl.GL_DEPTH_TEST);
            Gl.glEnable(Gl.GL_LIGHTING);
            Gl.glEnable(Gl.GL_LIGHT0);

            // установка первых элементов в списках combobox
            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;

            // активация таймера, вызывающего функцию для визуализации
            RenderTimer.Start();

            for (int i = 0; i < 6; i++)
            {
                var x = rnd_next.Next(-2, 2);
                var y = rnd_next.Next(-2, 2);
                var z = rnd_next.Next(-15, 10);

                figureCoords[i] = new TranslationCoord(x, y, z);
            }
        }

        private void RenderTimer_Tick(object sender, EventArgs e)
        {
            // вызываем функцию отрисовки сцены
            Draw();
        }

        private void trackBar1_Scroll_1(object sender, EventArgs e)
        {
            // переводим значение, установившееся в элементе trackBar, в необходимый нам формат
            a = (double)trackBar1.Value / 1000.0;
            // подписываем это значение в label элементе под данным ползунком
            label8.Text = a.ToString();
        }

        private void trackBar2_Scroll_1(object sender, EventArgs e)
        {
            // переводим значение, установившееся в элементе trackBar, в необходимый нам формат
            b = (double)trackBar2.Value / 1000.0;
            // подписываем это значение в label элементе под данным ползунком
            label9.Text = b.ToString();
        }

        private void trackBar3_Scroll_1(object sender, EventArgs e)
        {
            // переводим значение, установившееся в элементе trackBar, в необходимый нам формат
            c = (double)trackBar3.Value / 1000.0;
            // подписываем это значение в label элементе под данным ползунком
            label10.Text = c.ToString();
        }

        private void trackBar4_Scroll_1(object sender, EventArgs e)
        {
            // переводим значение, установившееся в элементе trackBar, в необходимый нам формат
            d = (double)trackBar4.Value;
            // подписываем это значение в label элементе под данным ползунком
            label11.Text = d.ToString();
        }

        private void trackBar5_Scroll_1(object sender, EventArgs e)
        {
            // переводим значение, установившееся в элементе trackBar, в необходимый нам формат
            zoom = (double)trackBar5.Value / 1000.0;
            // подписываем это значение в label элементе под данным ползунком
            label12.Text = zoom.ToString();
        }

        private void checkBox1_CheckedChanged_1(object sender, EventArgs e)
        {
            SpecialMode = checkBox1.Checked;
        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            // в зависимости от выбранного режима
            switch (comboBox1.SelectedIndex)
            {

                // устанавливаем необходимую ось (будет испльзовано в функции glRotate**)
                case 0:
                    {

                        os_x = 1;
                        os_y = 0;
                        os_z = 0;
                        break;

                    }
                case 1:
                    {

                        os_x = 0;
                        os_y = 1;
                        os_z = 0;
                        break;

                    }
                case 2:
                    {

                        os_x = 0;
                        os_y = 0;
                        os_z = 1;
                        break;

                    }
            }
        }

        // функция отрисовки
        private void Draw()
        {
            // очистка буфера цвета и буфера глубины
            Gl.glClear(Gl.GL_COLOR_BUFFER_BIT | Gl.GL_DEPTH_BUFFER_BIT);

            Gl.glClearColor(255, 255, 255, 1);
            // очищение текущей матрицы
            Gl.glLoadIdentity();

            // помещаем состояние матрицы в стек матриц, дальнейшие трансформации затронут только визуализацию объекта
            Gl.glPushMatrix();
            
            for (int i = 0; i < 6; i++)
            {
                Gl.glTranslated(figureCoords[i].X, figureCoords[i].Y, figureCoords[i].Z);
                // производим перемещение в зависимости от значений, полученных при перемещении ползунков
                Gl.glTranslated(a, b, c);
                // поворот по установленной оси
                Gl.glRotated(d, os_x, os_y, os_z);
                // и масштабирование объекта
                Gl.glScaled(zoom, zoom, zoom);

                // в зависимсоти от установленного типа объекта
                switch (comboBox2.SelectedIndex)
                {

                    // рисуем нужный объект, используя фунции бибилиотеки GLUT
                    case 0:
                        {

                            if (SpecialMode)
                            {
                                if (i != 2 && i != 5)
                                {
                                    Glut.glutSolidSphere(2, 16, 16);
                                }
                                else
                                {
                                    Glut.glutWireSphere(2, 16, 16);
                                }
                            }
                            else
                                Glut.glutSolidSphere(2, 16, 16); // полигональная сфера
                            break;

                        }
                    case 1:
                        {

                            if (SpecialMode)
                            {
                                if (i != 2 && i != 5)
                                {
                                    Glut.glutSolidCylinder(1, 2, 32, 32);
                                }
                                else
                                {
                                    Glut.glutWireCylinder(1, 2, 32, 32);
                                }
                            }
                            else
                                Glut.glutSolidCylinder(1, 2, 32, 32);
                            break;

                        }
                    case 2:
                        {

                            if (SpecialMode)
                            {
                                if (i != 2 && i != 5)
                                {
                                    Glut.glutSolidCube(2);
                                }
                                else
                                {
                                    Glut.glutWireCube(2);
                                }
                            }
                            else
                                Glut.glutSolidCube(2);
                            break;

                        }
                    case 3:
                        {

                            if (SpecialMode)
                            {
                                if (i != 2 && i != 5)
                                {
                                    Glut.glutSolidCone(2, 3, 32, 32);
                                }
                                else
                                {
                                    Glut.glutWireCone(2, 3, 32, 32);
                                }
                            }
                            else
                                Glut.glutSolidCone(2, 3, 32, 32);
                            break;

                        }
                    case 4:
                        {

                            if (SpecialMode)
                            {
                                if (i != 2 && i != 5)
                                {
                                    Glut.glutSolidTorus(0.2, 2.2, 32, 32);
                                }
                                else
                                {
                                    Glut.glutWireTorus(0.2, 2.2, 32, 32);
                                }
                            }
                            else
                                Glut.glutSolidTorus(0.2, 2.2, 32, 32);
                            break;
                        }
                }
            }

            // возвращаем состояние матрицы
            Gl.glPopMatrix();

            // завершаем рисование
            Gl.glFlush();

            // обновляем элемент AnT
            AnT.Invalidate();
        }
    }
}
