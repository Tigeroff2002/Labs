﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

// для работы с библиотекой OpenGL 
using Tao.OpenGl;
// для работы с библиотекой FreeGLUT 
using Tao.FreeGlut;
// для работы с элементом управления SimpleOpenGLControl 
using Tao.Platform.Windows;

namespace Parakhin_Kirill_PRI_120_Lab_9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            AnT.InitializeContexts();
        }

        // коэффициенты из варианта 25
        private float zoom_sx = 2f;
        private float zoom_sy = 0.5f;

        private float translate_tx = -250f;
        private float translate_ty = 150f;

        private float rotate_alpha = (float) (-Math.PI / 2);

        private float[,] GeomObject = new float[200, 3];

        private int final_outside_index;

        private int final_inside_circle_index;

        private int final_object_index;

        private int count_elements = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            // инициализация Glut 
            Glut.glutInit();
            Glut.glutInitDisplayMode(Glut.GLUT_RGB | Glut.GLUT_DOUBLE | Glut.GLUT_DEPTH);

            // очистка окна 
            Gl.glClearColor(255, 255, 255, 1);

            // установка порта вывода в соотвествии с размерами элемента anT 
            Gl.glViewport(0, 0, AnT.Width, AnT.Height);

            // настройка проекции 
            Gl.glMatrixMode(Gl.GL_PROJECTION);
            Gl.glLoadIdentity();

            Glu.gluPerspective(45, (float)AnT.Width / (float)AnT.Height, 0.1, 200);

            Gl.glMatrixMode(Gl.GL_MODELVIEW);

            Gl.glLoadIdentity();

            Gl.glEnable(Gl.GL_DEPTH_TEST);

            // задание вершин двумерного объекта
            GeomObject[0, 0] = 100;
            GeomObject[0, 1] = 180;

            GeomObject[1, 0] = 140;
            GeomObject[1, 1] = 180;

            GeomObject[2, 0] = 140;
            GeomObject[2, 1] = 170;

            GeomObject[3, 0] = 150;
            GeomObject[3, 1] = 170;

            GeomObject[4, 0] = 150;
            GeomObject[4, 1] = 140;

            GeomObject[5, 0] = 110;
            GeomObject[5, 1] = 140;

            GeomObject[6, 0] = 110;
            GeomObject[6, 1] = 130;

            GeomObject[7, 0] = 150;
            GeomObject[7, 1] = 130;

            GeomObject[8, 0] = 150;
            GeomObject[8, 1] = 60;

            GeomObject[9, 0] = 110;
            GeomObject[9, 1] = 60;

            GeomObject[10, 0] = 110;
            GeomObject[10, 1] = 50;

            GeomObject[11, 0] = 150;
            GeomObject[11, 1] = 50;

            GeomObject[12, 0] = 150;
            GeomObject[12, 1] = 10;

            GeomObject[13, 0] = 10;
            GeomObject[13, 1] = 10;

            GeomObject[14, 0] = 10;
            GeomObject[14, 1] = 50;

            GeomObject[15, 0] = 50;
            GeomObject[15, 1] = 50;

            GeomObject[16, 0] = 50;
            GeomObject[16, 1] = 50;

            GeomObject[17, 0] = 50;
            GeomObject[17, 1] = 60;

            GeomObject[18, 0] = 10;
            GeomObject[18, 1] = 60;

            GeomObject[19, 0] = 10;
            GeomObject[19, 1] = 130;

            GeomObject[20, 0] = 50;
            GeomObject[20, 1] = 130;

            GeomObject[21, 0] = 50;
            GeomObject[21, 1] = 140;

            GeomObject[22, 0] = 10;
            GeomObject[22, 1] = 140;

            GeomObject[23, 0] = 10;
            GeomObject[23, 1] = 170;

            GeomObject[24, 0] = 20;
            GeomObject[24, 1] = 170;

            GeomObject[25, 0] = 20;
            GeomObject[25, 1] = 180;

            GeomObject[26, 0] = 60;
            GeomObject[26, 1] = 180;

            var currentIndex = 27;

            float radius = 20;
            float centerX = 80, centerY = 180;
            float step = 0.05f;

            var pi = (float)Math.PI;

            double X, Y;

            for (float k = -pi / 2; k <= pi / 2; k += step)
            {
                X = Math.Sin(k) * radius + centerX;
                Y = Math.Cos(k) * radius + centerY;

                GeomObject[currentIndex, 0] = (float)X;
                GeomObject[currentIndex, 1] = (float)Y;

                currentIndex++;
            }

            final_outside_index = currentIndex;

            float[,] CircleArray = new float[7, 2];
            float topX = 80, topY = 200,
            rightX = 100, rightY = 180,
            leftX = 60, leftY = 180,
            bottomX = 80, bottomY = 160;

            CircleArray[0, 0] = topX;
            CircleArray[0, 1] = topY;
            CircleArray[1, 0] = leftX;
            CircleArray[1, 1] = leftY;
            CircleArray[2, 0] = bottomX;
            CircleArray[2, 1] = bottomY;
            CircleArray[3, 0] = rightX;
            CircleArray[3, 1] = rightY;
            CircleArray[4, 0] = topX;
            CircleArray[4, 1] = topY;
            CircleArray[5, 0] = leftX;
            CircleArray[5, 1] = leftY;
            CircleArray[6, 0] = bottomX;
            CircleArray[6, 1] = bottomY;

            double xA, xB, xC, xD, yA, yB, yC, yD, t;
            double a0, a1, a2, a3, b0, b1, b2, b3;

            var N = 4;

            for (var i = 1; i < 5; i++)
            {
                xA = CircleArray[i - 1, 0];
                xB = CircleArray[i, 0];
                xC = CircleArray[i + 1, 0];
                xD = CircleArray[i + 2, 0];

                yA = CircleArray[i - 1, 1];
                yB = CircleArray[i, 1];
                yC = CircleArray[i + 1, 1];
                yD = CircleArray[i + 2, 1];

                a3 = (-xA + 3 * (xB - xC) + xD) / 6.0;
                a2 = (xA - 2 * xB + xC) / 2.0;
                a1 = (xC - xA) / 2.0;
                a0 = (xA + 4 * xB + xC) / 6.0;
                b3 = (-yA + 3 * (yB - yC) + yD) / 6.0;
                b2 = (yA - 2 * yB + yC) / 2.0;
                b1 = (yC - yA) / 2.0;
                b0 = (yA + 4 * yB + yC) / 6.0;

                for (var j = 0; j <= 5; j++)
                {
                    t = (double)j / (double)N;
                    X = (((a3 * t + a2) * t + a1) * t + a0);
                    Y = (((b3 * t + b2) * t + b1) * t + b0);

                    GeomObject[currentIndex, 0] = (float)X;
                    GeomObject[currentIndex, 1] = (float)Y;

                    currentIndex++;
                }
            }

            final_inside_circle_index = currentIndex - 1;

            GeomObject[currentIndex, 0] = 40;
            GeomObject[currentIndex++, 1] = 80;

            GeomObject[currentIndex, 0] = 120;
            GeomObject[currentIndex++, 1] = 80;

            GeomObject[currentIndex, 0] = 120;
            GeomObject[currentIndex++, 1] = 100;

            GeomObject[currentIndex, 0] = 40;
            GeomObject[currentIndex++, 1] = 100;

            GeomObject[currentIndex, 0] = 40;
            GeomObject[currentIndex, 1] = 80;

            final_object_index = currentIndex;

            count_elements = currentIndex + 1;

            // задаем для всех точек нулевую кооординату по z

            for (int i = 0; i < count_elements; i++)
            {
                GeomObject[i, 0] /= 100;
                GeomObject[i, 1] /= 100;
                GeomObject[i, 2] = 1;
            }

            comboBox1.SelectedIndex = 0;

            RenderTimer.Start();
        }


        private void Draw()
        {
            Gl.glClear(Gl.GL_COLOR_BUFFER_BIT | Gl.GL_DEPTH_BUFFER_BIT);
            Gl.glClearColor(255, 255, 255, 1);

            Gl.glLoadIdentity();

            Gl.glColor3f(0, 0, 0);

            Gl.glPushMatrix();

            Gl.glTranslated(0, 0, -7);

            Gl.glRotated(15, 1, 1, 0);

            Gl.glPushMatrix();

            // начинаем отрисовку внешнего контура объекта
            Gl.glBegin(Gl.GL_LINE_LOOP);

            // геометрические данные ме берем из массива GeomObject
            // рисуем объект с помощью замкнутой линии
            for (int i = 0; i <= final_outside_index - 1; i++)
            {
                var X = GeomObject[i, 0];
                var Y = GeomObject[i, 1];
                var Z = GeomObject[i, 2];

                Gl.glVertex3d(X, Y, Z);
            }

            // завершаем отрисовку примитивов
            Gl.glEnd();

            // начинаем отрисовку внутренней окружности
            Gl.glBegin(Gl.GL_LINE_LOOP);

            // геометрические данные ме берем из массива GeomObject
            // рисуем объект с помощью замкнутой линии
            for (int i = final_outside_index + 1; i <= final_inside_circle_index; i++)
            {
                var X = GeomObject[i, 0];
                var Y = GeomObject[i, 1];
                var Z = GeomObject[i, 2];

                Gl.glVertex3d(X, Y, Z);
            }

            // завершаем отрисовку примитивов
            Gl.glEnd();

            // начинаем отрисовку внутреннего прямоугольника
            Gl.glBegin(Gl.GL_LINE_LOOP);

            // геометрические данные ме берем из массива GeomObject
            // рисуем объект с помощью замкнутой линии
            for (int i = final_inside_circle_index + 1; i <= final_object_index; i++)
            {
                var X = GeomObject[i, 0];
                var Y = GeomObject[i, 1];
                var Z = GeomObject[i, 2];

                Gl.glVertex3d(X, Y, Z);
            }

            // завершаем отрисовку примитивов
            Gl.glEnd();

            // возвращаем состояние матрицы
            Gl.glPopMatrix();

            Gl.glPopMatrix();

            // дожидаемся конца визуализации кадра 
            Gl.glFlush();

            // посылаем сигнал перерисовки элемента AnT. 
            AnT.Invalidate();
        }

        private void RenderTimer_Tick(object sender, EventArgs e)
        {
            Draw();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            AnT.Focus();
        }

        private void AnT_KeyDown(object sender, KeyEventArgs e)
        {
            // Z и X отвечают за масштабирование
            if (e.KeyCode == Keys.Z)
            {
                float coef;

                if (comboBox1.SelectedIndex == 0) // X
                {
                    coef = zoom_sx;
                }
                else // Y,Z
                {
                    coef = zoom_sy;
                }

                // вызов функции, в которой мы реализуем масштабирование -
                // передаем коэфициент масштабирования и выбранную ось в окне программы
                CreateZoom(coef, comboBox1.SelectedIndex);
            }
            if (e.KeyCode == Keys.X)
            {
                float coef;

                if (comboBox1.SelectedIndex == 0) // X
                {
                    coef = zoom_sx;
                }
                else // Y,Z
                {
                    coef = zoom_sy;
                }

                // вызов функции, в которой мы реализуем масштабирование -
                // передаем коэфициент масштабирования и выбранную ось в окне программы
                CreateZoom(1 / coef, comboBox1.SelectedIndex);
            }

            // W и S отвечают за перенос
            if (e.KeyCode == Keys.W)
            {
                float coef;
                if (comboBox1.SelectedIndex == 0) // X
                {
                    coef = translate_tx;
                }
                else // Y, Z
                {
                    coef = translate_ty;
                }
                // вызов функции, в которой мы реализуем перенос -
                // передаем коэфициент переноса и выбранную ось в окне программы

                CreateTranslate(coef, comboBox1.SelectedIndex);
            }
            if (e.KeyCode == Keys.S)
            {
                float coef;
                if (comboBox1.SelectedIndex == 0) // X
                {
                    coef = translate_tx;
                }
                else // Y,Z
                {
                    coef = translate_ty;
                }
                // вызов функции, в которой мы реализуем перенос -
                // передаем коэфициент переноса и выбранную ось в окне программы
                CreateTranslate(-coef, comboBox1.SelectedIndex);
            }

            // A и D отвечают за поворот
            if (e.KeyCode == Keys.A)
            {
                // вызов функции, в которой мы реализуем поворот -
                // передаем угол поворота относительно оси Z
                CreateRotate(rotate_alpha, comboBox1.SelectedIndex);
            }
            if (e.KeyCode == Keys.D)
            {
                // вызов функции, в которой мы реализуем поворот -
                // передаем угол поворота относительно оси Z
                CreateRotate(-rotate_alpha, comboBox1.SelectedIndex);
            }
        }

        // функция масштабирования
        private void CreateZoom(float coef, int os)
        {
            // создаем матрицу
            float[,] Zoom2D = new float[3, 3];
            Zoom2D[0, 0] = 1;
            Zoom2D[1, 0] = 0;
            Zoom2D[2, 0] = 0;

            Zoom2D[0, 1] = 0;
            Zoom2D[1, 1] = 1;
            Zoom2D[2, 1] = 0;

            Zoom2D[0, 2] = 0;
            Zoom2D[1, 2] = 0;
            Zoom2D[2, 2] = 1;

            // устанавливаем коэфицент масштабирования для необходимой (выбранной и переданной в качестве параметра) оси
            Zoom2D[os, os] = coef;

            // вызываем функцию для выполнения умножения матрицы
            // координт вершин геометрического объекта
            // на созданную в данной функции матрицу
            multiply(GeomObject, Zoom2D);
        }

        // функция переноса
        private void CreateTranslate(float translate, int os)
        {
            // создаем матрицу
            float[,] Tran2D = new float[3, 3];
            Tran2D[0, 0] = 1;
            Tran2D[1, 0] = 0;
            Tran2D[2, 0] = 0;

            Tran2D[0, 1] = 0;
            Tran2D[1, 1] = 1;
            Tran2D[2, 1] = 0;

            Tran2D[0, 2] = 0;
            Tran2D[1, 2] = 0;
            Tran2D[2, 2] = 1;

            // устанавливаем коэфицент переноса для необходимой (выбранной и переданной в качестве параметра) оси
            Tran2D[2, os] = translate;

            // вызываем функцию для выполнения умножения матрицы
            // координт вершин геометрического объекта
            // на созданную в данной функции матрицу
            multiply(GeomObject, Tran2D);
        }

        // реализация поворота
        private void CreateRotate(float angle, int os)
        {
            float[,] Rotate3D = new float[3, 3];

            switch (os)
            {
                case 0:
                    {
                        Rotate3D[0, 0] = 1;
                        Rotate3D[1, 0] = 0;
                        Rotate3D[2, 0] = 0;

                        Rotate3D[0, 1] = 0;
                        Rotate3D[1, 1] = (float)Math.Cos(angle);
                        Rotate3D[2, 1] = (float)-Math.Sin(angle);

                        Rotate3D[0, 2] = 0;
                        Rotate3D[1, 2] = (float)Math.Sin(angle);
                        Rotate3D[2, 2] = (float)Math.Cos(angle);
                        break;
                    }
                case 1:
                    {
                        Rotate3D[0, 0] = (float)Math.Cos(angle);
                        Rotate3D[1, 0] = 0;
                        Rotate3D[2, 0] = (float)Math.Sin(angle);

                        Rotate3D[0, 1] = 0;
                        Rotate3D[1, 1] = 1;
                        Rotate3D[2, 1] = 0;

                        Rotate3D[0, 2] = (float)-Math.Sin(angle);
                        Rotate3D[1, 2] = 0;
                        Rotate3D[2, 2] = (float)Math.Cos(angle);
                        break;
                    }
                case 2:
                    {
                        Rotate3D[0, 0] = (float)Math.Cos(angle);
                        Rotate3D[1, 0] = (float)-Math.Sin(angle);
                        Rotate3D[2, 0] = 0;

                        Rotate3D[0, 1] = (float)Math.Sin(angle);
                        Rotate3D[1, 1] = (float)Math.Cos(angle);
                        Rotate3D[2, 1] = 0;

                        Rotate3D[0, 2] = 0;
                        Rotate3D[1, 2] = 0;
                        Rotate3D[2, 2] = 1;
                        break;
                    }
            }

            multiply(GeomObject, Rotate3D);
        }

        // функция умножения вектора координат точек объекта на матрицу преобразования
        private void multiply(float[,] obj, float[,] matrix)
        {
            float res_1, res_2, res_3;

            for (int ax = 0; ax < count_elements; ax++)
            {
                res_1 = (obj[ax, 0] * matrix[0, 0] + obj[ax, 1] * matrix[0, 1] + obj[ax, 2] * matrix[0, 2]);
                res_2 = (obj[ax, 0] * matrix[1, 0] + obj[ax, 1] * matrix[1, 1] + obj[ax, 2] * matrix[1, 2]);
                res_3 = (obj[ax, 0] * matrix[2, 0] + obj[ax, 1] * matrix[2, 1] + obj[ax, 2] * matrix[2, 2]);

                obj[ax, 0] = res_1;
                obj[ax, 1] = res_2;
                obj[ax, 2] = res_3;
            }
        }
    }
}
