﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Parakhin_Kirill_Lab2_2
{
    public partial class AboutProgram : Form
    {
        Image logo;

        string path = "_logo.png";

        public AboutProgram()
        {
            InitializeComponent();

            logo = Image.FromFile(path);
            this.Size = logo.Size;
            pictureBox1.Image = logo;
            pictureBox1.Size = logo.Size;
        }
    }
}
