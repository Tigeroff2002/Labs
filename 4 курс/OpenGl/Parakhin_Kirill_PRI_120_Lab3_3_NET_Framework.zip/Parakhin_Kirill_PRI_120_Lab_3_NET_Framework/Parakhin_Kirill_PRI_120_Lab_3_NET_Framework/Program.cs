﻿using System;
using System.Text;
using System.Threading;

namespace Parakhin_Kirill_PRI_120_Lab3
{
    public class Program
    {
        public static void Main(string[] args) //точка входа в программу
        {
            Console.OutputEncoding = Encoding.UTF8;

            //создаем 4 потока, в качестве параметров передаем имя Выполняемой функции
            var a = -2.5f;
            var b = 2.5f;
            var c = 30;

            var action = new Action(() => Variant24_Result(a, b, c));
            Thread th_1 = new Thread(() => action());
            Thread th_2 = new Thread(() => action());
            Thread th_3 = new Thread(() => action());
            Thread th_4 = new Thread(() => action());

            //расставляем приоритеты для потоков

            th_1.Priority = ThreadPriority.Highest; // самый высокий
            th_2.Priority = ThreadPriority.BelowNormal; // выше среднего
            th_3.Priority = ThreadPriority.Normal; // средний
            th_4.Priority = ThreadPriority.Lowest; // низкий

            th_1.Start();
            th_2.Start();
            th_3.Start();
            th_4.Start();

            Console.WriteLine("все потоки запущены\n\n");
            //Ждем завершения каждого потока
            th_1.Join();
            th_2.Join();
            th_3.Join();
            th_4.Join();

            Console.ReadKey(); // прочитать символ: пока пользователь не нажмет клавишу, программа не завершится (чтобы можно было успеть посмотреть результат)).
        }

        private static void Variant24_Result(float a, float b, int c)
        {
            if (a >= b)
            {
                throw new ArgumentException("a should be less than b");
            }

            var n = c;

            var h = (b - a) / n;

            for (var i = 0; i < n; i++)
            {
                var x = a + i * h;

                var result =
                    0.3 * (Math.Exp(3 * Math.Log(x)) + Math.Exp(2 * Math.Log(x)) - 1) +
                    0.1 * Math.Tan(0.2 * x + 1) -
                    Math.Log(5 * Math.Tan(x)) -
                    Math.Exp(7 * Math.Sqrt(x));

                if (!double.IsNaN(result)
                    && !double.IsInfinity(result))
                {
                    Console.WriteLine($"Current thread - {Thread.CurrentThread.ManagedThreadId}, i = {i}, n = {n}, Yi = {result}");
                }
            }
        }
    }
}