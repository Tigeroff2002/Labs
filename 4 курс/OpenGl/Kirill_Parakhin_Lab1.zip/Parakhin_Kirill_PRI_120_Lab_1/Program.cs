﻿using Parakhin_Kirill_PRI_120_Lab_1;
using System.Text;

public class Program
{
    /// <summary>
    /// Представляет точку входа в программу.
    /// </summary>
    /// <param name="args">
    /// Аргументы.
    /// </param>
    public static void Main(string[] args)
    {
        // устанавливаем по умолчанию русскую кодировку
        Console.OutputEncoding = Encoding.UTF8;

        const string fio = "Парахин Кирилл Валерьевич";

        const string group = "ПРИ-120";

        Console.WriteLine($"Программа была выполнена студентом группы {group}," +
            $" его полное имя - {fio}");

        // переменная, которая будет хранить команду пользователя
        string user_command = "";

        // бесконечный цикл
        bool Infinity = true;

        Man SomeMan = null!;

        while (Infinity) // пока Infinity равно true
        {
            // приглашение ввести команду
            Console.WriteLine("Пожалуйста, введите команду");

            // получение строки (команды) от пользователя
            user_command = Console.ReadLine();

            // обработка команды с помощью оператора ветвления
            switch (user_command)
            {

                // если user_command содержит строку exit
                case "exit":
                    {
                        Infinity = false;
                        // теперь цикл завершиться, и программа завершит свое выполнение
                        break;
                    }
                // если user_command содержит строку help
                case "help":
                    {

                        Console.WriteLine("Список команд:");
                        Console.WriteLine("---");

                        Console.WriteLine("create_man : команда создает человечка, (экземпляр класса Man)");
                        Console.WriteLine("kill_man : команда убивает человечка");
                        Console.WriteLine("talk : команда заставляет человечка говорить (если создан экземпляр класса)");
                        Console.WriteLine("go : команда заставляет человечка идти (если создан экземпляр класса)");
                        Console.WriteLine("do_sport: команда заставляет человека " +
                            "идти заниматься спортом");
                        Console.WriteLine("feed: команда дает покушать человеку");
                        Console.WriteLine("heal: команда вызывает лечение человека");
                        Console.WriteLine("marry: команда заставляет жениться" +
                            " человека");
                        Console.WriteLine("---");

                        break;

                    }
                case "create_man":
                    {
                        // проверяем, создан ли уже какой либо человечек
                        if (SomeMan != null)
                        {
                            // человечек уже существует - "убиваем" его
                            SomeMan.Kill();
                        }
                        // просим ввести имя человечка
                        Console.WriteLine("Пожалуйста, введите имя создаваемого человечка \n");

                        // получаем строку введенную пользователем
                        user_command = Console.ReadLine();

                        // создаем новый объект в памяти, в качестве параметра
                        // передаем имя человечка
                        SomeMan = new Man(user_command);

                        // сообщаем о создании
                        Console.WriteLine("Человечек успешно создан \n");

                        break;
                    }
                case "kill_man":
                    {
                        // проверяем, что объект существует в памяти
                        if (SomeMan != null)
                        {
                            // вызываем фукнцию "смерти"
                            SomeMan.Kill();
                        }

                        break;
                    }
                case "talk":
                    {
                        // проверяем, что объект существует в памяти
                        if (SomeMan != null)
                        {
                            // вызываем фукнцию разговора
                            SomeMan.Talk();
                        }
                        else // иначе
                        {
                            Console.WriteLine("Человечек не создан. Команда не может быть выполнена");
                        }
                        break;

                    }
                case "go":
                    {

                        // проверяем, что объект существует в памяти
                        if (SomeMan != null)
                        {
                            // вызываем фукнцию передвижения
                            SomeMan.Go();
                        }
                        else
                        {
                            Console.WriteLine("Человечек не создан. Команда не может быть выполнена");
                        }
                        break;

                    }
                case "do_sport":
                    {
                        // проверяем, что объект существует в памяти
                        if (SomeMan != null)
                        {
                            // вызываем функцию занятия спортом
                            SomeMan.DoSport();
                        }
                        else
                        {
                            Console.WriteLine("Человечек не создан. Команда не может быть выполнена");
                        }
                        break;
                    }
                case "feed":
                    {
                        // проверяем, что объект существует в памяти
                        if (SomeMan != null)
                        {
                            // вызываем функцию кормления персонажа
                            SomeMan.Feed();
                        }
                        else
                        {
                            Console.WriteLine("Человечек не создан. Команда не может быть выполнена");
                        }
                        break;
                    }
                case "heal":
                    {
                        // проверяем, что объект существует в памяти
                        if (SomeMan != null)
                        {
                            // вызываем функцию лечения персонажа
                            SomeMan.Heal();
                        }
                        else
                        {
                            Console.WriteLine("Человечек не создан. Команда не может быть выполнена");
                        }
                        break;
                    }
                case "marry":
                    {
                        // проверяем, что объект существует в памяти
                        if (SomeMan != null)
                        {
                            // вызываем функцию бракосочетания персонажа
                            SomeMan.Marry();
                        }
                        else
                        {
                            Console.WriteLine("Человечек не создан. Команда не может быть выполнена");
                        }
                        break;
                    }

                // если команду определить не удалось
                default:
                    {

                        Console.WriteLine("Ваша команда не определена, пожалуйста повторите снова");
                        Console.WriteLine("Для вывода списка команд введите команду help");
                        Console.WriteLine("Для завершения программы введите команду exit");
                        break;
                    }
            }
        }
    }
}