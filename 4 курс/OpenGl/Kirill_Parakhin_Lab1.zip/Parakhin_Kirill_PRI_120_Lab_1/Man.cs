﻿namespace Parakhin_Kirill_PRI_120_Lab_1
{
    /// <summary>
    /// Представляет человека.
    /// </summary>
    public sealed class Man
    {
        /// <summary>
        /// Создает экземпляр <see cref="Man"/>.
        /// </summary>
        /// <param name="_name">
        /// Имя человека.
        /// </param>
        public Man(string _name)
        {
            Name = _name;
            isLife = true;

            // генерируем возраст от 15 до 50
            Age = (uint)rnd.Next(15, 50);
            // и здоровье, от 10 до 100%
            Health = (uint)rnd.Next(10, 50);

            isSeek = Health <= 40;
            isHungry = (uint)rnd.Next(1, 2) % 2 == 1;

            isGoodFeeling = !isSeek && !isHungry;

            isMarried = false;
        }

        // закрытые члены, которые нельзя именить
        // извне класса

        // строка, содержащая имя
        private string Name;

        // беззнаковое целое число, содержащая возраст
        private uint Age;

        // беззнаковое целое число, отражающее уровень здоровья
        private uint Health;

        // булево, означающее жив ли данный человечек
        private bool isLife;

        // булево значение, означающее, женат ли человек
        private bool isMarried;

        // булево значение, означающее, голоден ли человек
        private bool isHungry;

        // булево значение, означающее, имеет ли температуру человек
        private bool isSeek;

        // булево значение, означающее, что человек очень хорошо себя чувствует
        private bool isGoodFeeling;

        private Random rnd = new Random();

        // заготовка функции "говорить"
        public void Talk()
        {
            if (isLife)
            {
                // генерируем случайное число от 1 до 5
                int random_talk = rnd.Next(1, 5);

                // объявляем переменную, в которой мы будем хранить строку
                string tmp_str = "";

                // в зависимости от случайного значения random_talk
                switch (random_talk)
                {

                    case 1: // если 1 - называем свое имя
                        {
                            // генериуем текст сообщения
                            tmp_str = "Привет, меня зовут " + Name + ", рад познакомиться";

                            // завершаем оператор выбора
                            break;
                        }

                    case 2: // возраст
                        {
                            // генериуем текст сообщения
                            tmp_str = "Мне " + Age + ". А тебе?";
                            // завершаем оператор выбора
                            break;
                        }

                    case 3: // говорим о своем самочувствии
                        {
                            // в зависимости от параметра сочувствия
                            if (isGoodFeeling)
                            {
                                tmp_str = "Я хорошо себя ощущаю, и здоров и не голоден";
                            }
                            else
                            {
                                // в зависимости от параметра голода
                                if (isHungry)
                                {
                                    if (isSeek)
                                    {
                                        tmp_str = "Сейчас я болею и к тому же очень голоден!";
                                    }
                                    else
                                    {
                                        tmp_str = "Сейчас пока я только голоден!";
                                    }
                                }
                                else
                                {
                                    tmp_str = "Сейчас я не голоден, но испытываю болезнь";
                                }
                            }


                            // завершаем оператор выбора
                            break;
                        }

                    case 4: // говорит о факте своей женитьбы
                        {
                            // генерируем текст сообщения
                            if (isMarried)
                            {
                                var countYears = rnd.Next(2, 4);

                                tmp_str = "Я женат ужe " + countYears + " года";
                            }
                            else
                            {
                                tmp_str = "Я пока не женат";
                            }

                            // завершаем оператор выбора
                            break;
                        }
                }

                // выводим на консоль сгенерированное сообщение
                Console.WriteLine(tmp_str);
            }
            else
            {
                // генерируем строку текста
                string outString = Name + " не может разговаривать, так как он умер";
                Console.WriteLine(outString);
            }
        }

        // заготовка функции "идти"
        public void Go()
        {
            // если объект жив
            if (isLife == true)
            {
                if (!isSeek)
                {
                    if (Health < 70)
                    {
                        // генерируем строку текста
                        string outString = Name + " мирно прогуливается по городу";

                        isSeek = false;

                        // выводим в консоль
                        System.Console.WriteLine(outString);
                    }
                    else if (Health > 70)
                    {
                        // генерируем строку текста
                        string outString = Name + " с большим удовольствием крупным шагом прогуливается по городу";

                        isSeek = false;

                        // выводим в консоль
                        System.Console.WriteLine(outString);
                    }
                }
                else
                {
                    // генерируем строку текста
                    string outString = Name + " болен и не может гулять по городу";

                    isSeek = true;

                    // выводим в консоль
                    System.Console.WriteLine(outString);
                }
            }
            else
            {
                // генерируем строку текста
                string outString = Name + " не может идти, он умер";
                Console.WriteLine(outString);
            }
        }

        public void Kill()
        {
            if (!isLife)
            {
                Console.WriteLine("Персонаж уже умер");
            }

            // устанавливаем значение isLife (жив)
            // в false...
            isLife = false;

            isGoodFeeling = false;
            isHungry = false;
            isMarried = false;
            isSeek = false;

            Console.WriteLine("Персонаж был убит");
        }

        // функция, возвращающая показатель - жив ли данный человечек.
        public bool IsAlive()
        {
            // возращаем значение, к которому мы не можем
            // обратиться на прямую из вне класса,
            // так как оно имеет статус private

            // сбрасываем все остальные значения, если человек мертв
            if (!isLife)
            {
                isGoodFeeling = false;
                isHungry = false;
                isMarried = false;
                isSeek = false;
            }

            return isLife;
        }

        // возвращает факт того, что человек хорошо себя чувствует
        public bool isGoodFeelingNow()
        {
            return isGoodFeeling;
        }

        // персонаж будет заниматься спортом
        public void DoSport()
        {
            if (isLife)
            {
                isGoodFeeling = !isSeek & !isHungry;
                if (isGoodFeeling)
                {
                    string outString = Name + " имеет хорошее самочувствие и готов заниматься спортом";
                    Console.WriteLine(outString);
                }
                else if (isSeek)
                {
                    string hungryMatter = isHungry ? " и голоден" : "";
                    string outString = Name + " болен" + hungryMatter + ", поэтому не будет заниматься спортом";
                    string addString = "Но вы можете попробовать его вылечить с помощью команды 'heal'";
                    Console.WriteLine(outString);
                    Console.WriteLine(addString);
                }
                else if (isHungry)
                {
                    string outString = Name + " голоден, поэтому не желает заниматься спортом";
                    string addString = "Но вы можете его покормить с помощью команды 'feed'";
                    Console.WriteLine(outString);
                    Console.WriteLine(addString);
                }
            }
            else
            {
                // генерируем строку текста
                string outString = Name + " не может заниматься спортом, он умер";
                Console.WriteLine(outString);
            }
        }

        // функция с помощью которой можно покормить персонажа
        public void Feed()
        {
            if (isLife)
            {
                if (isHungry)
                {
                    string outString = Name + " покушал и теперь не голоден";
                    isHungry = false;

                    // обновляем значение самочувствия, зависящее только от факта болезни
                    isGoodFeeling = isSeek;

                    Console.WriteLine(outString);
                }
                else
                {
                    string outString = Name + " не голоден и не хочет есть";
                    Console.WriteLine(outString);
                }
            }
            else
            {
                // генерируем строку текста
                string outString = Name + " не может кушать, так как он умер";
                Console.WriteLine(outString);
            }
        }

        // функция с помощью которой можно попробовать вылечить персонажа
        public void Heal()
        {
            if (isLife)
            {
                if (isSeek)
                {
                    string outString = Name + " болен и хочет пройти лечение";
                    string secondString = "Введите целое число: ";

                    Console.WriteLine(outString);
                    Console.Write(secondString);

                    try
                    {
                        var value = Convert.ToInt32(Console.ReadLine());

                        string thirdString = "";

                        if (rnd.Next(1, 2) == value % 2)
                        {
                            isSeek = false;

                            // обновляем значение самочувствия, зависящее только от факта голода
                            isGoodFeeling = isHungry;

                            thirdString = Name + " смог успешно вылечиться благодаря вашей помощи";
                        }
                        else
                        {
                            thirdString = Name + " не смог пока пойти на поправку";
                        }

                        Console.WriteLine(thirdString);
                    }
                    catch(Exception ex)
                    {
                        Console.WriteLine("Произошла ошибка ввода данных..");
                    }
                }
                else
                {
                    string outString = Name + " не болен и не нуждается в лечении";
                    Console.WriteLine(outString);
                }
            }
            else
            {
                // генерируем строку текста
                string outString = Name + " не может кушать, так как он умер";
                Console.WriteLine(outString);
            }
        }

        // функция с помощью которой можно женить персонажа
        public void Marry()
        {
            if (isLife)
            {
                if (!isMarried)
                {
                    string outString = Name + " еще не женат и будет жениться";
                    isMarried = true;
                    Console.WriteLine(outString);
                }
                else
                {
                    string outString = Name + " уже женат и не может жениться повторно";
                    Console.WriteLine(outString);
                }
            }
            else
            {
                // генерируем строку текста
                string outString = Name + " не может кушать, так как он умер";
                Console.WriteLine(outString);
            }
        }

        // возвращает факт того, что человек женат
        public bool isMarriedNow()
        {
            return isMarried;
        }
    }
}
