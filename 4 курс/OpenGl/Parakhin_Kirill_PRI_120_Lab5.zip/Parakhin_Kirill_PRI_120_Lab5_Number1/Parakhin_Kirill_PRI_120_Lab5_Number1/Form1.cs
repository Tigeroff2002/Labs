﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

// для работы с библиотекой OpenGL 
using Tao.OpenGl;
// для работы с библиотекой FreeGLUT 
using Tao.FreeGlut;
// для работы с элементом управления SimpleOpenGLControl 
using Tao.Platform.Windows;

namespace Parakhin_Kirill_PRI_120_Lab5_Number1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            AnT.InitializeContexts();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            // инициализация Glut 
            Glut.glutInit();
            Glut.glutInitDisplayMode(Glut.GLUT_RGB | Glut.GLUT_DOUBLE | Glut.GLUT_DEPTH);

            // очистка окна 
            Gl.glClearColor(255, 255, 255, 1);

            // установка порта вывода в соотвествии с размерами элемента anT 
            Gl.glViewport(0, 0, AnT.Width, AnT.Height);


            // настройка проекции 
            Gl.glMatrixMode(Gl.GL_PROJECTION);
            Gl.glLoadIdentity();

            // теперь необходимо корректно настроить 2D ортогональную проекцию
            // в зависимости от того, какая сторона больше 
            // мы немного варьируем то, как будут сконфигурированы настройки проекции

            if ((float)AnT.Width <= (float)AnT.Height)
            {
                Glu.gluOrtho2D(0.0, 30.0 * (float)AnT.Height / (float)AnT.Width, 0.0, 30.0);
            }
            else
            {
                Glu.gluOrtho2D(0.0, 30.0 * (float)AnT.Width / (float)AnT.Height, 0.0, 30.0);
            }

            Gl.glMatrixMode(Gl.GL_MODELVIEW);
            Gl.glLoadIdentity();

            // настройка параметров OpenGL для визуализации 
            Gl.glEnable(Gl.GL_DEPTH_TEST);
            Gl.glEnable(Gl.GL_COLOR_MATERIAL);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // очищаем буфер цвета 
            Gl.glClear(Gl.GL_COLOR_BUFFER_BIT | Gl.GL_DEPTH_BUFFER_BIT);

            // очищаем текущую матрицу 
            Gl.glLoadIdentity();
            // устанавливаем текущий цвет - оранжевый
            Gl.glColor3f(255, 120, 0);
            Gl.glLineWidth(3f);


            // активируем режим рисования линий на основе 
            // последовательного соединения всех вершин отрезками 

            // рисуем букву П
            Gl.glBegin(Gl.GL_LINES);
            Gl.glVertex2d(0.3, 5);
            Gl.glVertex2d(0.3, 10);
            Gl.glVertex2d(0.3, 10);
            Gl.glVertex2d(4, 10);
            Gl.glVertex2d(4, 10);
            Gl.glVertex2d(4, 5);
            // завершаем режим рисования 
            Gl.glEnd();

            // рисуем букву А
            Gl.glBegin(Gl.GL_LINES);
            Gl.glVertex2d(6, 5);
            Gl.glVertex2d(7.5, 10);
            Gl.glVertex2d(7.5, 10);
            Gl.glVertex2d(9, 5);
            Gl.glVertex2d(6, 7);
            Gl.glVertex2d(9, 7);
            // завершаем режим рисования 
            Gl.glEnd();

            // рисуем букву Р
            Gl.glBegin(Gl.GL_LINES);
            Gl.glVertex2d(11, 5);
            Gl.glVertex2d(11, 10);
            Gl.glVertex2d(11, 10);
            Gl.glVertex2d(14, 10);
            Gl.glVertex2d(14, 10);
            Gl.glVertex2d(14, 7.8);
            Gl.glVertex2d(14, 7.8);
            Gl.glVertex2d(11, 7.8);
            // завершаем режим рисования 
            Gl.glEnd();

            // рисуем букву А
            Gl.glBegin(Gl.GL_LINES);
            Gl.glVertex2d(16, 5);
            Gl.glVertex2d(17.5, 10);
            Gl.glVertex2d(17.5, 10);
            Gl.glVertex2d(19, 5);
            Gl.glVertex2d(16, 7);
            Gl.glVertex2d(19, 7);
            // завершаем режим рисования 
            Gl.glEnd();

            // рисуем букву X
            Gl.glBegin(Gl.GL_LINES);
            Gl.glVertex2d(21, 5);
            Gl.glVertex2d(24, 10);
            Gl.glVertex2d(24, 5);
            Gl.glVertex2d(21, 10);
            // завершаем режим рисования 
            Gl.glEnd();

            // рисуем букву И
            Gl.glBegin(Gl.GL_LINES);
            Gl.glVertex2d(26, 10);
            Gl.glVertex2d(26, 5);
            Gl.glVertex2d(26, 5);
            Gl.glVertex2d(29, 10);
            Gl.glVertex2d(29, 10);
            Gl.glVertex2d(29, 5);
            // завершаем режим рисования 
            Gl.glEnd();

            // рисуем букву Н
            Gl.glBegin(Gl.GL_LINES);
            Gl.glVertex2d(31, 5);
            Gl.glVertex2d(31, 10);
            Gl.glVertex2d(34, 5);
            Gl.glVertex2d(34, 10);
            Gl.glVertex2d(31, 7.5);
            Gl.glVertex2d(34, 7.5);
            // завершаем режим рисования 
            Gl.glEnd();

            // рисуем букву К
            Gl.glBegin(Gl.GL_LINES);
            Gl.glVertex2d(37, 5);
            Gl.glVertex2d(37, 10);
            Gl.glVertex2d(37, 7.5);
            Gl.glVertex2d(40, 10);
            Gl.glVertex2d(37, 7.5);
            Gl.glVertex2d(40, 5);
            // завершаем режим рисования 
            Gl.glEnd();

            // рисуем букву В
            Gl.glBegin(Gl.GL_LINES);
            Gl.glVertex2d(42, 5);
            Gl.glVertex2d(42, 10);
            Gl.glVertex2d(42, 10);
            Gl.glVertex2d(45, 7.8);
            Gl.glVertex2d(45, 7.8);
            Gl.glVertex2d(42, 7.8);
            Gl.glVertex2d(44.8, 5);
            Gl.glVertex2d(44.8, 7.8);
            Gl.glVertex2d(44.8, 5);
            Gl.glVertex2d(42, 5);
            // завершаем режим рисования 
            Gl.glEnd();

            // дожидаемся конца визуализации кадра 
            Gl.glFlush();

            // посылаем сигнал перерисовки элемента AnT. 
            AnT.Invalidate();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
